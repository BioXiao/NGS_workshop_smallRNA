"""
Tools for masking out specific sites in aligments by various criteria, for
example masking CpG sites or sites with low sequence quality.
"""

from bx.align.sitemask.core import *

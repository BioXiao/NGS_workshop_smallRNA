"""
Support for the UCSC "Big Binary Indexed" file formats (bigWig and bigBed)
"""

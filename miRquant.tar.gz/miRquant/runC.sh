#!/bin/bash

#example call: ./runC.sh hsa /fullpathToDir/g1Results/CHR*.results

GENOME=$1
shift

for ARG in "$@"
do
  DIR=`dirname $ARG`
  BASE=`basename $ARG .results`
  NAME2=CollectLog_$BASE
  RUNDIR=$DIR/$BASE
  bsub -o 01_logs/$NAME2 -q hour perl -w 05_scripts/shrimp_collectRes.pl $RUNDIR $GENOME
done
